package com.javaufcd.exemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemplosApplicationTests {

	@Test
	void contextLoads() {
	}

}
